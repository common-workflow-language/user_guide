public class Hello {
  public static void main(String[] argv) {
    System.out.println("Hello from Java");
  }
}
